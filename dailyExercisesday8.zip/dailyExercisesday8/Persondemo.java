package com.java.dailyExercisesday8;

public class Persondemo {
    public static void main(String[] args) {
                Student st = new Student("Deepu", 20, "Rise University", "Bachelor of Science");
                st.display();
    }
}

