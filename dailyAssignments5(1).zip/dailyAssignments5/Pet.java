package com.java.dailyAssignments5;

public interface Pet {
	//String (getName);
	void setName(String name);
	void play();
	String getName();
	

}