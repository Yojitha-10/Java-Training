package com.java.dailyExercisesday4;
class Animal {
 public void shout() {
     System.out.println("Some generic animal sound");
 }
}






