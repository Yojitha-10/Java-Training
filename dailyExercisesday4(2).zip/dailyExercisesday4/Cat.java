package com.java.dailyExercisesday4;

class Cat extends Animal {
	 @Override
	 public void shout() {
	     System.out.println("Meow! Meow!");
	 }
}