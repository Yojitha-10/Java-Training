package com.java.dailyExercisesday4;

class Horse extends Animal {
	 @Override
	 public void shout() {
	     System.out.println("Neigh! Neigh!");
	 }
}