package com.java.dailyExercisesday4;

class Dog extends Animal {
	 @Override
	 public void shout() {
	     System.out.println("Woof! Woof!");
	 }
}