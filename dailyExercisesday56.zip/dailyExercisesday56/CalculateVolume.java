package com.java.dailyExercisesday56;

public interface CalculateVolume {
	double calculateVolume();
}